:template: index.html

============
Contents
============

.. toctree::
   :hidden:

   smart-contracts/index
   testnet/index
